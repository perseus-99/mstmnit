window.onscroll = function() {logo_reshape()};


function logo_reshape()
{
    if(document.body.scrollTop>50 || document.documentElement.scrollTop >50)
    {
        document.getElementById("logo-header").style.height="30px";
        document.getElementById("logo-header").style.width="30px";
    }
    
}