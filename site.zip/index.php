<?php
    session_start();
    require('db.php');
    if($_SERVER["REQUEST_METHOD"]=="POST"){
        $sport = $_POST["sport"];
        if($sport="cricket"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];
            $player8 = $_POST["player8"];
            $player9 = $_POST["player9"];
            $player10 = $_POST["player10"];
            $player11 = $_POST["player11"];
            $player12 = $_POST["player12"];
            $player13 = $_POST["player13"];
            $player14 = $_POST["player14"];
            $player15 = $_POST["player15"];

            $sql = "INSERT INTO cricket VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11,$player12,$player13,$player14,$player15);
            $stmt->execute();
            
            $stmt->close();
            $conn->close();
        }
        else if(sport=="table_tennis"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO table_tennis_men VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO table_tennis_women VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="badminton"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO badminton_men VALUES (?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO badminton_women VALUES (?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("sssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4);
                $stmt->execute();

                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="volleyball"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];
            $player8 = $_POST["player8"];
            $player9 = $_POST["player9"];
            $player10 = $_POST["player10"];
            $player11 = $_POST["player11"];

            
            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO volleyball_men VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO volleyball_women VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="basketball"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];
            $layer8 = $_POST["player8"];
            $player9 = $_POST["player9"];
            $player10 = $_POST["player10"];
            $player11 = $_POST["player11"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO basketball_men VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO basketball_women VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="football"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];
            $player8 = $_POST["player8"];
            $player9 = $_POST["player9"];
            $player10 = $_POST["player10"];
            $player11 = $_POST["player11"];
            $player12 = $_POST["player12"];
            $player13 = $_POST["player13"];
            $player14 = $_POST["player14"];
            $player15 = $_POST["player15"];

            $sql = "INSERT INTO football VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11,$player12,$player13,$player14,$player15);
            $stmt->execute();
            
            $stmt->close();
            $conn->close();
        }
        else if($sport=="tennis"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO tennis_men VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO tennis_women VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="gym"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];

            $type = $_POST["type"];
            if($type=="weight_lifting"){
                $sql = "INSERT INTO weight_lifting VALUES (?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="power_lifting"){
                $sql = "INSERT INTO power_lifting VALUES (?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="best_physique"){
                $sql = "INSERT INTO best_physique VALUES (?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="chess"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO chess_men VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO chess_women VALUES (?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss",$clg,$captain,$mobile,$player1,$player2,$player3);
                $stmt->execute();
                
                $stmt->close();
                $conn->close();
            }
        }
        else if($sport=="kabaddi"){
            $clg = $_POST["clg"];
            $captain = $_POST["team_captain"];
            $mobile = $_POST["mobile"];
            $player1 = $_POST["player1"];
            $player2 = $_POST["player2"];
            $player3 = $_POST["player3"];
            $player4 = $_POST["player4"];
            $player5 = $_POST["player5"];
            $player6 = $_POST["player6"];
            $player7 = $_POST["player7"];
            $player8 = $_POST["player8"];
            $player9 = $_POST["player9"];
            $player10 = $_POST["player10"];
            $player11 = $_POST["player11"];

            $type = $_POST["type"];
            if($type=="men"){
                $sql = "INSERT INTO kabaddi_men VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
            else if($type=="women"){
                $sql = "INSERT INTO kabaddi_women VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssssssssssss",$clg,$captain,$mobile,$player1,$player2,$player3,$player4,$player5,$player6,$player7,$player8,$player9,$player10,$player11);
                $stmt->execute();
                $stmt->close();
                $conn->close();
            }
        }
    }
?>


<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <link href="btn.css" rel="stylesheet">
    <link rel="shortcut icon" href="favicon.ico">
    <link rel="stylesheet" type="text/css" href="normalize.css" />
    <link rel="stylesheet" type="text/css" href="demo.css" />
    <link rel="stylesheet" type="text/css" href="component2.css" />
    <script src="modernizr-2.6.2.min.js"></script>
    <script src="fullPage.js"></script>
    <link rel="stylesheet" href="fullpage.css">
    <link rel="stylesheet" href="index.css">
    <link href='https://fonts.googleapis.com/css?family=Oswald' rel='stylesheet'>
    <link href="team.css" rel="stylesheet">
    <link href='https://fonts.googleapis.com/css?family=Ubuntu' rel='stylesheet'>

    <link href="animate.css" rel="stylesheet">
    <link href="sports.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>

       
        *{
            margin:0px;
        }
        
    </style>
</head>
<body>  
    <div class="main-line" style="bottom:10px;left:10px">  Navigation</div>
  
   <div class="circ-nav-cont">

            <div class="component">
			
			
                <div class ="container-btn-nav" id="cn-button" style="z-index: 1111;">
                    <div class="btn-nav" onclick="myFunction(this)">
                    <div class="bar1"></div>
                    <div class="bar2"></div>
                    
                    </div>
                    
                    </div>
				<div class="cn-wrapper" id="cn-wrapper">
					<ul>
						<li><a href="#1Page"><span>Home</span></a></li>
						<li><a href="#2Page"><span>About</span></a></li>
						<li><a href="#3Page"><span>Gallery</span></a></li>
						<li><a href="#4Page"><span>Sports</span></a></li>
						<li><a href="#5Page"><span>Team</span></a></li>
						<li><a href="#6Page"><span>Sponsors</span></a></li>
						<li><a href="#7Page"><span>Credits</span></a></li>
					 </ul>
                    </div>
                   
                
                </div>
                
            </div>
            <div id="bottom-panel"> 
                <div class="line"></div>
                <div class="line"></div>
            </div>
        
            
<div id="fullpage" >
    
    
    <div class="section active" id="section0" >
        <div id="cont-head" style="z-index: 200;">
        <div id="header">
            <img src="mstlogo.svg" alt="logo">
            <div id="headLine" style="width:100%; color:black; font-family:Oswald; text-align: center; background-color: rgba(255,255,255,0.2);"> MALAVIYA SPORTS TOURNAMENT</div>
            <div id="headLine" style="width:100%; color:black; font-family:Oswald; text-align: center; background-color: rgba(255,255,255,0.2);"> 3rd, 4th and 5th March, 2020</div>
        </div>
        <div class="countdown" id="countdown">
            <div class="cell" id="days"></div>
            <div class="cell" id="hrs"></div>
            <div class="cell" id="min"></div>
            <div class="cell" id="sec"></div>
        </div>
       
        </div>
        
        <video autoplay muted loop id="video-index">
            <source src="mst.mp4" type="video/mp4">
            Your browser does not support HTML5 video.
          </video>
    </div>
    <div class="section" id="section1">
        <div id="typography-heading">ABOUT</div>
        <div class="about">
            <div id="mission">
                <div id="aboutImg1">
                    <img src="sp1.svg"></div>
                    <div></div>
                    <div class="aboutText" style="padding:10% 0% 0% 0%;">
                       
                        <p style=" border-radius:100px 0% 0% 0%; padding:20px 100px">

                      
                    MNIT or Malaviya National Institute of Technology, Jaipur formerly
                    known as Malaviya Regional Engineering College (MREC) established in 
                        1963 is one of the national premier institutes, which completed its 
                        Golden Jubilee in 2013. It is founded by MHRD, the government of
                        India. It ahs ranked first among NITs and 23rd among institutions 
                        in the country as per SCIMAGO institutions rankings.
                        The main objective of the institute is to produce quality engineers 
                    </p>
                    <h1 style="text-align: right;padding:10px 100px">#aboutTheCollege</h1>
                    </div>
                </div>
          <div id="vision">

                <div class="aboutText" style="padding:0% 0% 0% 0%">
                    <h1 style="padding:10px 100px;">#aboutTheFest</h1>
                    <p style=" border-radius: 0% 0% 100px 0%; padding:20px 100px">MST is the annual sports tournament of MNIT Jaipur. It is going to be
                    organized from some March to March 2020. We, the biggest sports tournament of 
                    Rajasthan converging talent and enthusiasm. The tournament covers a plethora
                    of various sports and provides a platform for the best teams to fight it to grab the title.
                    With a participation of over 1300 students and more than 35 colleges 
                    and excitin cultural nights. MST '20 promises to enthrall its audience.
                </p>  </div>
                <div></div>
                    <div id="aboutImg2"><img src="sp2.svg"></div>
                    
            </div>
        </div>
 
        </div>
       
    <div class="section" id="section2">
        <div id="typography-heading" style="transform:matrix(0.00,-1.00,1.00,0.00,-60,90);">GALLERY</div>
                <div id="myCarousel" class="carousel slide" data-ride="carousel">
                  <!-- Indicators -->
                 
                  <!-- Wrapper for slides -->
                  <div class="carousel-inner" >
                    <div class="item active">
                      <img src="gal1.jpg" style="width:100%;">
                    </div>
              
                    <div class="item">
                      <img src=gal2.jpg" style="width:100%;">
                    </div>
                  
                    <div class="item">
                      <img src="gal3.jpg" style="width:100%;">
                    </div>

                    <div class="item">
                      <img src="gal4.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal5.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal6.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal7.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal8.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal9.jpg" style="width:100%;">
                    </div>
                    <div class="item">
                      <img src="gal10.jpg" style="width:100%;">
                    </div>
                  </div>
              
                  <!-- Left and right controls -->
                  <a class="left carousel-control" href="#myCarousel" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="right carousel-control" href="#myCarousel" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
              </div>
              

            <div class="section" id="section3">
                <div id="typography-heading" style="transform:matrix(0.00,-1.00,1.00,0.00,-60,70);">SPORTS</div>
                <div class="sports">
                    <div class="left">
                        <div class="row">
                            <div class="cell"><div class="overlay"></div><img src="cricket.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="table-tennis.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="badminton.jpg" class="img-sport"></div>
                        </div>
                        <div class="row">
                            <div class="cell"><div class="overlay"></div><img src="volleyball.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="basketball.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="football.jpg" class="img-sport"></div>
                          
                        </div>
                        <div class="row">
                            <div class="cell"><div class="overlay"></div><img src="tennis.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="weights.jpg" class="img-sport"></div>
                            <div class="cell"><div class="overlay"></div><img src="chess.jpg" class="img-sport"></div>
                        
                        </div>
                        <div class="row">
                            <div class="cell" style="width:40%"><div class="overlay"></div><img src="kabaddi.jpeg" class="img-sport"></div>
                  
                           
                        </div>
                     
                    </div>
                    <div class="right">
                      

                        #cricket
                        <form class ="sp-reg-form" id = "cricket" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="cricket">
                            College Name : <input type="text" name="clg">
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            Player12 : <input type="text" name="player12">
                            Player13 : <input type="text" name="player13">
                            Player14 : <input type="text" name="player14">
                            Player15 : <input type="text" name="player15">
                            <button type="submit">Register</button>
                        </form>

                        #Table Tennis 
                        <form id="table-tennis" class="sp-reg-form" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="table_tennis">
                            College Name : <input type="text" name="clg">
                            Type : 
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            <button type="submit">Register</button>
                        </form>

                        #Badminton
                        <form method="POST" id="badminton" class="sp-reg-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="badminton">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            <button type="submit">Register</button>
                        </form>

                        #Volleyball
                        <form method="POST" class="sp-reg-form" id="volleyball" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="volleyball">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            <button type="submit">Register</button>
                        </form>

                        #Basketball
                        <form method="POST" class="sp-reg-form" id="basketball" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="basketball">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            <button type="submit">Register</button>
                        </form>


                        #Football
                        <form method="POST" class="sp-reg-form" id="football" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="football">
                            College Name : <input type="text" name="clg">
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            Player12 : <input type="text" name="player12">
                            Player13 : <input type="text" name="player13">
                            Player14 : <input type="text" name="player14">
                            Player15 : <input type="text" name="player15">
                            <button type="submit">Register</button>
                        </form>

                        #Tennis
                        <form method="POST" class="sp-reg-form" id="tennis" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="tennis">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            <button type="submit">Register</button>
                        </form>


                        #GYM
                        <form method="POST" class="sp-reg-form" id="gym" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="gym">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="weight_lifting">Weight Lifting</option>
                                <option value="power_lifting">Power Lifting</option>
                                <option value="best_physique">Best Physique</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            <button type="submit">Register</button>
                        </form>

                        #Chess
                        <form class="sp-reg-form" id="chess" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="chess">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            <button type="submit">Register</button>
                        </form>

                        #Kabaddi
                        <form class="sp-reg-form" id="kabaddi" method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                            <input type="hidden" name="sport" value="kabaddi">
                            College Name : <input type="text" name="clg">
                            Type:
                            <select name="type">
                                <option value="men">Men</option>
                                <option value="women">Women</option>
                            </select>
                            Team Captain : <input type="text" name="team_captain">
                            Mobile No. : <input type="text" name="mobile">
                            Player1 : <input type="text" name="player1">
                            Player2 : <input type="text" name="player2">
                            Player3 : <input type="text" name="player3">
                            Player4 : <input type="text" name="player4">
                            Player5 : <input type="text" name="player5">
                            Player6 : <input type="text" name="player6">
                            Player7 : <input type="text" name="player7">
                            Player8 : <input type="text" name="player8">
                            Player9 : <input type="text" name="player9">
                            Player10 : <input type="text" name="player10">
                            Player11 : <input type="text" name="player11">
                            <button type="submit">Register</button>
                        </form>
                    </div>
                
            </div></div>
                
     <div class="section" id="section4">
        <div id="typography-heading" style="transform:matrix(0.00,-1.00,1.00,0.00,0,30);">TEAM</div>
  <div class="team-cont" id="team">
       <div class="team-img-cont"></div>
       <div class="team-img-cont"></div>
       <div class="team-img-cont"></div>
       <div class="team-img-cont"></div>
       <div class="team-img-cont"></div>
        </div>
        <div class="prev-block" onclick=updateTemp(-1)>
<button class="team-btn prev" > <i class="fa fa-arrow-left"></i> </button></div>
<div class="nxt-block" onclick=updateTemp(1)>
<button class="team-btn next" > <i class="fa fa-arrow-right"></i> </button></div>
    </div>
    <div class="section" id="section5">
        <div id="typography-heading" style="transform:matrix(0.00,-1.00,1.00,0.00,-90,130);">SPONSORS</div>
<div class="sponsors">
    <div class="row">
        <div class="ele"><img src="s1.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s2.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s3.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s4.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s5.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s6.jpg" style="height:100%;width:100%"></div>
    </div>
    <div class="row">
        <div class="ele"><img src="s7.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s8.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s9.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s10.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s11.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s12.png" style="height:100%;width:100%"></div>
    </div>
    <div class="row">
        <div class="ele"><img src="s13.jfif" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s14.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s15.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s16.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s24.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s17.jpg" style="height:100%;width:100%"></div>
    </div>
    <div class="row">
        <div class="ele"><img src="s18.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s19.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s20.png" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s21.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s22.jpg" style="height:100%;width:100%"></div>
        <div class="ele"><img src="s23.png" style="height:100%;width:100%"></div>
    </div>
</div>
    </div>
   
</div>
<div class="contact-nav" id="contact-nav">
    <div class="contact"></div>
    <div class="contact"><i class="fa fa-twitter"></i></div>
    <div class="contact"><i class="fa fa-facebook-f"></i></div>
    <div class="contact"></div>
    <div class="contact"><i class="fa fa-envelope"></i></div>
    <div class="contact"><i class="fa fa-instagram"></i></div>
    <div class="contact"></div>
</div>
<script src="polyfills.js"></script>
<script src="demo2.js"></script>
<script src="index.js"></script>

<script type="text/javascript">
    var myFullpage = new fullpage('#fullpage', {
        sectionsColor: ['#111', '#111 ', '#111', '#111', 'rgba(13,0,50,0.9)','#111','#A9999A'],
        anchors: ['1Page', '2Page', '3Page', '4Page', '5Page','6Page','7Page'],
        menu: '#menu',
        lazyLoad: true
    });
</script>
<script>
     function myFunct(x) {
    x.classList.add("anim");
</script>
<script>
    var tog=0;
    function myFunction(x) {
    x.classList.toggle("change");
if(tog==0){
    document.getElementById("contact-nav").style.display="grid";tog=1;
;}
    else if(tog==1)
    {
        document.getElementById("contact-nav").style.display="none";tog=0;
      
    }
    }
    </script>
<script>

window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("logo").style.height = "90px";
    document.getElementById("logo").style.width = "90px";
  }
  else{
    document.getElementById("logo").style.height = "200px";
    document.getElementById("logo").style.width = "200px";
  }
}
</script>
<script>

var cont=document.getElementById("team");
var current=1;
var tP=21;
var box1="<img src='p0.jpg' class='img-team'> <div class='content'> <h1>Anshul Bagrecha</h1><h2>none</h2></div> ";
        var box2="<img src='p1.jpg' class='img-team'> <div class='content'> <h1>Akhila Oruganti</h1><h2>Publicity</h2></div> ";
        var box3="<img src='p2.jpg' class='img-team'> <div class='content'> <h1>Yamini Kalyani</h1><h2>none</h2></div> ";
        var box4="<img src='p3.jpg' class='img-team'> <div class='content'> <h1>Harshiya Maheshwari</h1><h2>none</h2></div> ";
        var box5="<img src='p4.jpg' class='img-team'> <div class='content'> <h1>Shubam Kuri</h1><h2>Marketing</h2></div> ";
        var box6="<img src='p5.jpg' class='img-team'> <div class='content'> <h1> Dharshana Mittikayala </h1><h2>none</h2></div> ";
        var box7="<img src='p6.jpg' class='img-team'> <div class='content'> <h1>Sri Tej</h1><h2>none</h2></div> ";
        var box8="<img src='p7.jpg' class='img-team'> <div class='content'> <h1>Saptagirish S.</h1><h2>none</h2></div> ";
        var box9="<img src='p8.jpg' class='img-team'> <div class='content'> <h1>Harsh Yadav</h1><h2>none</h2></div> ";
        var box10="<img src='p9.jpg' class='img-team'> <div class='content'> <h1>Rahul Goyal</h1><h2>none</h2></div> ";
        var box11="<img src='p10.jpg' class='img-team'> <div class='content'> <h1>Gagan Mahala</h1><h2>none</h2></div> ";
        var box12="<img src='p11.jpg' class='img-team'> <div class='content'> <h1>Ambalika Singh</h1><h2>Event Management</h2></div> ";
        var box13="<img src='p12.jpg' class='img-team'> <div class='content'> <h1>Vivek Dhruwe</h1><h2>Logistics</h2></div> ";
        var box14="<img src='p13.jpg' class='img-team'> <div class='content'> <h1>Siva Krishna</h1><h2>none</h2></div> ";
        var box15="<img src='p14.jpg' class='img-team'> <div class='content'> <h1>Bidari Panindra Kumar</h1><h2>none</h2></div> ";
        var box16="<img src='p15.jpg' class='img-team'> <div class='content'> <h1>Meghali Singh</h1><h2>none</h2></div> ";
        var box17="<img src='p16.jpg' class='img-team'> <div class='content'> <h1>Rajat Kanojia</h1><h2>bcd</h2></div> ";
        var box18="<img src='p17.jpg' class='img-team'> <div class='content'> <h1>Aishwarya Murali</h1><h2>none</h2></div> ";
        var box19="<img src='p18.jpg' class='img-team'> <div class='content'> <h1>Durga Prasad</h1><h2>Marketing Secretary</h2></div> ";
        var box20="<img src='p19.jpg' class='img-team'> <div class='content'> <h1>Parth Goyal</h1><h2>none</h2></div> ";
        var box21="<img src='p20.jpg' class='img-team'> <div class='content'> <h1>Santoshi Manvita</h1><h2>Mass and Media</h2></div> ";
        var box22="<img src='p21.jpg' class='img-team'> <div class='content'> <h1>Gayatri Chadha</h1><h2>Event Management</h2></div> ";

      var list=[box1,box2,box3,box4,box5,box6,box7,box8,box9,box10,box11,box12,box13,box14,box15,box16,box17,box18,box19,box20,box21];

updateTemp(0);
    function updateTemp(change)
    {
        
        var i=cont.getElementsByClassName("team-img-cont");
     
        var p1=Math.abs(current+change)%tP;
       var p2=Math.abs(current+change+1)%tP;
       var p3=Math.abs(current+change+2)%tP;
       var p4=Math.abs(current+change+3)%tP;
       var p5=Math.abs(current+change+4)%tP;



       
      
      
    i[0].innerHTML=list[p1];
    i[1].innerHTML=list[p2];
    i[2].innerHTML=list[p3];
    i[3].innerHTML=list[p4];
    i[4].innerHTML=list[p5];
    
    
      current=(current+change);
     
           
     

    

    }
    

</script>
<script>
{
    var max=9;
    var min=1;

    var random1=Math.floor(Math.random() * (+max - +min)) + +min; 
    var random2=Math.floor(Math.random() * (+max - +min)) + +min; 
   
    if(random1==random2)
    {
        random2=Math.floor(Math.random() * (+max - +min)) + +min;
    }
    str1="sp"+random1+".svg";
    str2="sp"+random2+".svg";

    var obj1=document.getElementById("aboutImg1");
    var elem=obj1.getElementsByTagName("img");
    elem[0].src=str1;
    var obj2=document.getElementById("aboutImg2");
    var elem1=obj1.getElementsByTagName("img");
    elem1[0].src=str2;}

</script>
<script>
// When the user scrolls down 50px from the top of the document, resize the header's font size
window.onscroll = function() {scrollFunction()};

function scrollFunction() {
  if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
    document.getElementById("header").style.height = "70px";
    document.getElementById("header").style.width = "120px";
    document.getElementById("headLine").style.fontSize="7px";
    document.getElementById("cont-head").style.display="block";

  } else {
    document.getElementById("header").style.height = "200px";
    document.getElementById("header").style.width = "250px";
    document.getElementById("headLine").style.fontSize="13px";
    document.getElementById("cont-head").style.display="flex";
  }
}
</script>
<script>
// Set the date we're counting down to
var countDownDate = new Date("Mar 3, 2020 00:00:00").getTime();

// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("days").innerText=days+'d';
  document.getElementById("hrs").innerText=hours+'h';
  document.getElementById("min").innerText=minutes+'m';
  document.getElementById("sec").innerText=seconds+'s';
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>

</body>
</html>


